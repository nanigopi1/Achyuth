import { Component } from '@angular/core';
import { UserService } from './user.service';
import { HttpResponse, HttpEventType } from '@angular/common/http';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  /*title = 'catalogue';
  public userFile:any=File;
  file:any;*/
  public imagePath;
  imgURL:any;
  constructor(private userService:UserService){}
  selectedFiles: FileList;
  currentFileUpload: File;
  dataone:any[];
  id:number;
  name:string;
  address:string;
  /* ImgUrl:any={};
  this.ImgUrl = this.inspectionDetails.reportImage;
this.base64Image = this._sanitizer.bypassSecurityTrustResourceUrl(this.ImgUrl); */
 /* onSelectedFile(event){
    const file=event.target.files;
    this.userFile=file;
    console.log(this.userFile);
  }
  submit(){
    
    console.log(this.userFile);
    this.userService.saveProfile(this.userFile).subscribe(response=>console.log(response));
  }*/
  selectFile(event) {
    this.selectedFiles = event.target.files;
  }
  upload() {
   // this.progress.percentage = 0;
 
    this.currentFileUpload = this.selectedFiles.item(0);
    this.userService.saveProfile(this.currentFileUpload).subscribe(event => {
      
    });
 
    this.selectedFiles = undefined;
  }
  getdata(){
    console.log("hiii");
    this.userService.getdata().subscribe((data:any)=>this.dataone=data);
    /*this.userService.getdata().subscribe((data)=>{this.data1=data;
    for (const name in this.data1) {
      if (this.data1.hasOwnProperty(this.data1.name)){
         const element = this.data1[name];
         console.log(element);
      }
    }
  });*/
  
}
} 