import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from '../../node_modules/rxjs';




@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { 
    this.http=http;
  }
  saveProfile(file: File):Observable<any>{
    const formdata=new FormData();
    formdata.append('file',file);
    return this.http.post("http://localhost:9888/customer/saveUserProfile",formdata, {
      reportProgress: true,
      responseType: 'text'
    });
    
  }

  getdata(){
    return this.http.get("http://localhost:9888/customer/getall");
  }
}
